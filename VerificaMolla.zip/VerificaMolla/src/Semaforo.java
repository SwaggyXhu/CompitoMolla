import java.lang.System.Logger;

public class Semaforo {
    
 private int value=1;

  public Semaforo(){

  }



public synchronized void P(){

    while(value==0){
        
    try{
        System.out.println(Thread.currentThread().getName() +"----------------In Attesa al box ------------------");
        wait();

    }catch(InterruptedException ex){
        
    }       


       }
       value --;
  }


   public synchronized void V(){
     value ++;
     notifyAll();

   }

}
