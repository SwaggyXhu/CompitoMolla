public class Box {
   

public Box(){

}

public void Arrivo (){

 System.out.println(Thread.currentThread().getName()+" Arriva ai box --------->");


}


public void cambio(){
    try{
        int tempo = (int)(Math.random()*5+1)*1000;
        Thread.sleep(tempo);
    System.out.println(Thread.currentThread().getName()+" Cambio gomme in corso ");
    }catch(InterruptedException ex){

    }

}






public void Fine(){

  
    System.out.println( Thread.currentThread().getName() + " Finito ");
    
  
}




}





















