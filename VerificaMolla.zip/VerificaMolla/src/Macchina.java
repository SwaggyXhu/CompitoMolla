public class Macchina extends Thread{
    
 private Box B;
 private static Semaforo su=new Semaforo();
 private String nome;


 public Macchina(Box B, String name,String nome){
    super(name);
    this.B=B;
    this.nome=nome;
 }



@Override 
public void run(){

 

 for(int i=1;i<11;i++){
    System.out.println(super.getName() + " Fine " +i+ " Giro");
    if(i==3||i==6||i==9 ){
        su.P();
        B.Arrivo();
        B.cambio();
        B.Fine();
        su.V();
    }
 }


}



}
