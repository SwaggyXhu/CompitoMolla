public class App {
    public static void main(String[] args) throws Exception {
        System.out.println("Hello, World!");


     Box b=new Box();

     Macchina m1 =new Macchina(b,"Verstappen","Redbull");
     Macchina m2 =new Macchina(b,"Leclerc","Ferrari");
     Macchina m3 =new Macchina(b,"Hmilton ","Mercedez");
    

     System.out.println("--------->INIZIO CORSA<----------");
     m1.start();
     m2.start();
     m3.start();
     m1.join();
     m2.join();
     m3.join();
     System.out.println("CORSA FINITA");



    }
}
